package com.cms.repository;

import org.springframework.data.repository.CrudRepository;

import com.cms.entity.Schedule;

public interface ScheduleRepository extends CrudRepository<Schedule, Integer> {

}
